<?php

namespace App\Package\Ical\Property;

use App\Package\Ical\Output\ToIcalInterface;

interface PropertyInterface extends ToIcalInterface
{
    //
}
