<?php

namespace MicroSpaceless\Ical\Property;

use MicroSpaceless\Ical\Output\ToIcalInterface;

interface PropertyInterface extends ToIcalInterface
{
    //
}
