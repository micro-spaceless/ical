<?php

namespace MicroSpaceless\Ical\Output;

interface ToIcalInterface
{
    public function toIcal();
}
