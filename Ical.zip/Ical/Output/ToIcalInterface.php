<?php

namespace App\Package\Ical\Output;

interface ToIcalInterface
{
    public function toIcal();
}
